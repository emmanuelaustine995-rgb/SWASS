# swass-api

Phase 1 of SWASS: database, login with roles, and receipt creation.

## Status

| Part | State |
| --- | --- |
| `migrations/*.sql` and `scripts/migrate.sh` | Migration scripts included; apply to a fresh PostgreSQL database |
| `test/db_rules.sql` (12 database rule checks) | Passing |
| `src/` NestJS API (login, role guard, receipt creation and offline sync) | Implemented; build/runtime verification still required |
| `test/api.test.mjs` | Includes integration coverage; run against a disposable PostgreSQL database and running API |

## Run it

```bash
npm install
export DATABASE_URL=postgres://user:pass@localhost:5432/swass
export JWT_SECRET=$(openssl rand -hex 32)
export SWASS_ID_SECRET=$(openssl rand -hex 32)   # keep this secret and backed up: IDs cannot be re-matched without it
./scripts/migrate.sh
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f test/db_rules.sql   # runs in a rolled-back transaction
export CORS_ORIGINS=https://your-frontend.example.com # comma-separated trusted browser origins
npm run build
npm run start:dev          # terminal 1
npm run test:api           # terminal 2, use a throwaway database
```

## Receipt creation rules (`POST /api/v1/receipts`)

One database transaction that:

1. returns the stored receipt if `clientUuid` was already saved (no double charge on retry);
2. requires an active subscription (3 days of grace after expiry);
3. requires the wallet to cover the KSh 2 fee within the overdraft limit;
4. prices items from the database, never from the client;
5. requires buyer name, phone and National ID for items flagged `requires_buyer_id`;
6. limits cashier discounts (default 5%, `CASHIER_MAX_DISCOUNT_PCT`);
7. deducts stock, charges the fee, and awards loyalty points (1 point per KSh 100, adjustable).

Any failure rolls everything back.


## Current implementation boundaries

The current API phase includes tenant/store/user foundations, role-based receipt issuance, customer capture with keyed National ID hashes, subscription and prepaid-wallet enforcement, inventory deductions, loyalty ledger entries, and bounded offline receipt sync. It does **not** yet include the production integrations for M-Pesa STK Push/callback reconciliation, SMS/WhatsApp/email providers, OTP receipt recovery, thermal-printer browser workflows, or the super-admin analytics UI. Those require provider credentials, frontend work, and dedicated endpoints and must not be represented as live until integrated and tested.

### Security notes

- Use a unique random `JWT_SECRET` and `SWASS_ID_SECRET`, each at least 32 characters; keep them outside source control.
- Configure `CORS_ORIGINS` to the exact trusted frontend origins. Do not use wildcard origins with authenticated endpoints.
- `request_hash` is an HMAC of the normalized sale request; it does not store raw National ID values.
- A customer's existing National ID binding cannot be silently replaced by a different ID supplied with the same phone number.
- Apply migrations to a backup or disposable database first. Never run integration tests against production data.
