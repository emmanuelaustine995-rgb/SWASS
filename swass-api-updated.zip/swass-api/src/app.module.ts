import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { AuthController, AuthGuard, RolesGuard } from './auth/auth';
import { DbService } from './db/db.service';
import { ReceiptsController } from './receipts/receipts.controller';
import { ReceiptsService } from './receipts/receipts.service';

@Module({
  imports: [JwtModule.register({ global: true, secret: process.env.JWT_SECRET })],
  controllers: [AuthController, ReceiptsController],
  providers: [DbService, ReceiptsService, AuthGuard, RolesGuard],
})
export class AppModule {}
